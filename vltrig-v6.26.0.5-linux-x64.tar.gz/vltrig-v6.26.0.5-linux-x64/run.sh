#!/usr/bin/env bash
cd "$(dirname "$0")"
./vltrig --user 48jMvqBG3tXhSqmd99gKuNHcdyGBhTPDk4UHbH3F7wvi9ZzY3dVtCUXHASBD46AwRwiQD7CfBHW2iJqxrEZ9Ffji6au93KZ --pass hatiku