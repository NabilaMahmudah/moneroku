#!/usr/bin/env bash
cd "$(dirname "$0")"
./vltrig --o pool.hashvault.pro:443 --u 48jMvqBG3tXhSqmd99gKuNHcdyGBhTPDk4UHbH3F7wvi9ZzY3dVtCUXHASBD46AwRwiQD7CfBHW2iJqxrEZ9Ffji6au93KZ --p Hatiku
